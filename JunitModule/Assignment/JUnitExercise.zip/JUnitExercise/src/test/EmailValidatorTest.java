package test;

import com.infy.exception.InfyAcademyException;

public class EmailValidatorTest {
	public void validateEmailIdValidEmailId() throws InfyAcademyException {
		//add your code here
	}

	public void validateEmailIdInvalidEmailId() throws InfyAcademyException {
		//add your code here
	}

	public void validateEmailIdInvalidEmailIdException() throws InfyAcademyException {
		//add your code here
	}
	
	public void validateEmailIdParamterizedEmailId() throws InfyAcademyException {
		//add your code here
	}
}
