package test;

import com.infy.exception.InfyAcademyException;

public class PasswordValidatorTest {
	
	public void validatePasswordValidPassword() throws InfyAcademyException {
		//add your code here
	}
	
	public void validatePasswordInvalidPassword() throws InfyAcademyException {
		//add your code here
	}
	
	public void validatePasswordInvalidPasswordException() throws InfyAcademyException {
		//add your code here
	}
	
	public void validatePasswordParameterizedPassword() throws InfyAcademyException {
		//add your code here
	}
}