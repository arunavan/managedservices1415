package DIP;

public enum Role {
    PARENT,
    CHILD
}
