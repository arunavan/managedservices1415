package DIP;

public class Person {
    public String name;
    public Enum role;

    public Person(String name, Enum role) {
        this.name = name;
        this.role = role;
    }
}
