package ISP;

public interface Fax {
    void InternetFax(Document d) throws Exception;
}
