package ISP;

public interface MultiFunctionDevice extends Printer, Scanner, Fax {
}
