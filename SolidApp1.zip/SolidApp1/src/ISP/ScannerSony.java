package ISP;

public class ScannerSony implements Scanner {
    public void Scan(Document d) {
        System.out.println("Scan the text from the document: " + d);
    }
}