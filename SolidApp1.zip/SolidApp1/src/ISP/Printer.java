package ISP;

public interface Printer {
    void Print(Document d) throws Exception;
}
