package ISP;

public interface Scanner {
    void Scan(Document d) throws Exception;
}
