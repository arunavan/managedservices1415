package OCP;

public enum Size {
    SMALL,
    MEDIUM,
    LARGE,
}
