package OCP;

public enum Color {
    RED,
    GREEN,
    BLUE
}
